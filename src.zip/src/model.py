import torch.nn as nn
import torch.nn.functional as F

class CNNPlaque(nn.Module):
    def __init__(self, num_classes):
        super(CNNPlaque, self).__init__()
        self.conv1 = nn.Conv2d(3, 32, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.dropout = nn.Dropout(0.25)
        self.fc1 = nn.Linear(64 * 32 * 32, 256)
        self.fc2 = nn.Linear(256, num_classes)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))  # [batch, 32, 64, 64]
        x = self.pool(F.relu(self.conv2(x)))  # [batch, 64, 32, 32]
        x = x.view(-1, 64 * 32 * 32)          # Flatten
        x = self.dropout(x)
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x