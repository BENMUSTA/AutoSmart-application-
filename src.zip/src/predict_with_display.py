import torch
import torchvision.transforms as transforms
import cv2
from PIL import Image
from model import CNNPlaque

# ⚙️ Paramètres
MODEL_PATH = "models/plaque_model.pth"
IMAGE_PATH = "data/Test/00005.png"  # <-- adapte à ton image
NUM_CLASSES = 43
IMAGE_SIZE = (128, 128)

# 📦 Prétraitement de l'image
transform = transforms.Compose([
    transforms.Resize(IMAGE_SIZE),
    transforms.ToTensor()
])

def charger_image_tensor(image_path):
    image = Image.open(image_path).convert("RGB")
    return transform(image).unsqueeze(0)

# 🧠 Charger le modèle
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = CNNPlaque(num_classes=NUM_CLASSES).to(device)
model.load_state_dict(torch.load(MODEL_PATH, map_location=device))
model.eval()

# 🔍 Charger image et prédire
image_tensor = charger_image_tensor(IMAGE_PATH).to(device)
with torch.no_grad():
    output = model(image_tensor)
    _, predicted = torch.max(output, 1)
    predicted_class = predicted.item()

# 🖼️ Affichage avec OpenCV
image_cv = cv2.imread(IMAGE_PATH)
if image_cv is not None:
    cv2.putText(image_cv, f"Prediction: {predicted_class}", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    cv2.imshow("Prediction", image_cv)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
else:
    print("❌ Erreur : Impossible d'afficher l'image avec OpenCV.")
