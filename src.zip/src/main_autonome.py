import cv2
import time
import torch
import torchvision.transforms as transforms
from PIL import Image
from collections import deque
from moteurs import avancer, reculer, tourner_gauche, tourner_droite, stop
from ultrason import mesurer_distance
from ligne_detection import analyser_ligne
from model import CNNPlaque
from class_names import id_to_label

MODEL_PATH = "models/plaque_model.pth"
NUM_CLASSES = 43
IMAGE_SIZE = (128, 128)

transform = transforms.Compose([
    transforms.Resize(IMAGE_SIZE),
    transforms.ToTensor()
])

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = CNNPlaque(num_classes=NUM_CLASSES).to(device)
model.load_state_dict(torch.load(MODEL_PATH, map_location=device))
model.eval()

def lire_panneau(frame):
    image_pil = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    input_tensor = transform(image_pil).unsqueeze(0).to(device)
    with torch.no_grad():
        output = model(input_tensor)
        probabilities = torch.nn.functional.softmax(output, dim=1)
        confidence, predicted = torch.max(probabilities, 1)
        if confidence.item() < 0.75:
            return None, "Inconnu"
        class_id = predicted.item()
        label = id_to_label.get(class_id, "Inconnu")
        return class_id, label

camera = cv2.VideoCapture(0)
if not camera.isOpened():
    print("❌ Caméra non détectée")
    exit()

panneau_buffer = deque(maxlen=3)
dernier_panneau = 0
erreurs_distance = 0

try:
    while True:
        distance = mesurer_distance()
        if distance == -1:
            erreurs_distance += 1
            if erreurs_distance > 3:
                print("❌ Capteur ultrason bloqué → arrêt")
                stop()
                break
        else:
            erreurs_distance = 0

        if 0 < distance < 20:
            print(f"[DISTANCE] {distance} cm | Obstacle détecté")
            reculer()
            time.sleep(0.5)
            stop()

            if time.time() - dernier_panneau > 2:
                ret, frame = camera.read()
                if not ret:
                    continue
                _, label = lire_panneau(frame)
                panneau_buffer.append(label)
                dernier_panneau = time.time()
            else:
                label = "Inconnu"

            if panneau_buffer.count("STOP") >= 2:
                print("[ACTION] STOP → pause")
                stop()
                time.sleep(10)

            elif panneau_buffer.count("Turn left ahead") >= 2:
                print("[ACTION] Gauche")
                tourner_gauche()
                time.sleep(0.8)
                stop()

            elif panneau_buffer.count("Turn right ahead") >= 2:
                print("[ACTION] Droite")
                tourner_droite()
                time.sleep(0.8)
                stop()

            else:
                ret, frame = camera.read()
                if not ret:
                    continue
                direction = analyser_ligne(frame)
                print(f"[LIGNE] {direction}")
                if direction == "gauche":
                    tourner_gauche()
                elif direction == "droite":
                    tourner_droite()
                elif direction == "tout_droit":
                    avancer()
                else:
                    tourner_droite()
                    time.sleep(0.5)
                    avancer()
                    time.sleep(0.5)
                    stop()

        else:
            ret, frame = camera.read()
            if not ret:
                continue
            direction = analyser_ligne(frame)
            print(f"[DISTANCE] {distance} cm | [LIGNE] {direction}")
            if direction == "gauche":
                tourner_gauche()
            elif direction == "droite":
                tourner_droite()
            elif direction == "tout_droit":
                avancer()
            else:
                stop()

        time.sleep(0.1)

except KeyboardInterrupt:
    print("⛔ Arrêt manuel")

finally:
    stop()
    camera.release()
    cv2.destroyAllWindows()
