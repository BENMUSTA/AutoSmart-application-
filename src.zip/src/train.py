import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import torchvision.transforms as transforms
from dataset import PlaqueDataset
from model import CNNPlaque

# ⚙️ Paramètres
BATCH_SIZE = 32
EPOCHS = 10
LEARNING_RATE = 0.001
NUM_CLASSES = 43  # <-- à adapter selon ton dataset
CSV_PATH = "data/Train.csv"
DATA_PATH = "data"
IMAGE_SIZE = (128, 128)

# 📦 Transformations
transform = transforms.Compose([
    transforms.Resize(IMAGE_SIZE),
    transforms.ToTensor()
])

# 📊 Dataset et DataLoader
train_dataset = PlaqueDataset(CSV_PATH, DATA_PATH, transform=transform)
train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)

# 🧠 Modèle
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = CNNPlaque(num_classes=NUM_CLASSES).to(device)

# ⚙️ Optimiseur et perte
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)

# 🔁 Entraînement
print("🚀 Entraînement du modèle...")
for epoch in range(EPOCHS):
    running_loss = 0.0
    correct = 0
    total = 0

    for images, labels in train_loader:
        images, labels = images.to(device), labels.to(device)

        # 🔄 Forward + backward + optimise
        outputs = model(images)
        loss = criterion(outputs, labels)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # 🔎 Stats
        running_loss += loss.item()
        _, predicted = torch.max(outputs.data, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()

    acc = 100 * correct / total
    print(f"Epoch [{epoch+1}/{EPOCHS}] - Loss: {running_loss:.4f} - Accuracy: {acc:.2f}%")

# 💾 Sauvegarde
torch.save(model.state_dict(), "models/plaque_model.pth")
print("✅ Modèle sauvegardé dans models/plaque_model.pth")
