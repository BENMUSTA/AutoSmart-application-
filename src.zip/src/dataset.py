import os
import pandas as pd
from PIL import Image
from torch.utils.data import Dataset
import torchvision.transforms as transforms

class PlaqueDataset(Dataset):
    def __init__(self, csv_path, root_dir, transform=None):
        self.data = pd.read_csv(csv_path)
        self.root_dir = root_dir  
        self.transform = transform

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        rel_path = self.data.iloc[idx]["Path"]
        full_path = os.path.join(self.root_dir, rel_path)
        image = Image.open(full_path).convert("RGB")

        label = int(self.data.iloc[idx]["ClassId"])  

        if self.transform:
            image = self.transform(image)

        return image, label