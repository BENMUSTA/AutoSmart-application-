import RPi.GPIO as GPIO
import time

# Définir les broches des moteurs (via L298N)
IN1 = 17  # Moteur A
IN2 = 18
IN3 = 22  # Moteur B
IN4 = 27
ENA = 4   # PWM pour moteur A
ENB = 25  # PWM pour moteur B

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

GPIO.setup(IN1, GPIO.OUT)
GPIO.setup(IN2, GPIO.OUT)
GPIO.setup(IN3, GPIO.OUT)
GPIO.setup(IN4, GPIO.OUT)
GPIO.setup(ENA, GPIO.OUT)
GPIO.setup(ENB, GPIO.OUT)

# PWM configuration
pwm_a = GPIO.PWM(ENA, 1000)
pwm_b = GPIO.PWM(ENB, 1000)
pwm_a.start(60)  # 60% duty cycle
pwm_b.start(60)

# ==== Fonctions de mouvement ====

def avancer():
    GPIO.output(IN1, True)
    GPIO.output(IN2, False)
    GPIO.output(IN3, True)
    GPIO.output(IN4, False)

def reculer():
    GPIO.output(IN1, False)
    GPIO.output(IN2, True)
    GPIO.output(IN3, False)
    GPIO.output(IN4, True)

def tourner_gauche():
    GPIO.output(IN1, False)
    GPIO.output(IN2, True)
    GPIO.output(IN3, True)
    GPIO.output(IN4, False)

def tourner_droite():
    GPIO.output(IN1, True)
    GPIO.output(IN2, False)
    GPIO.output(IN3, False)
    GPIO.output(IN4, True)

def stop():
    GPIO.output(IN1, False)
    GPIO.output(IN2, False)
    GPIO.output(IN3, False)
    GPIO.output(IN4, False)

# Nettoyage (optionnel pour les tests manuels)
def cleanup():
    pwm_a.stop()
    pwm_b.stop()
    GPIO.cleanup()

# ==== Test (optionnel) ====
if __name__ == "__main__":
    try:
        avancer()
        time.sleep(2)
        tourner_gauche()
        time.sleep(1)
        tourner_droite()
        time.sleep(1)
        reculer()
        time.sleep(2)
        stop()
    except KeyboardInterrupt:
        cleanup()
