import torch
import torchvision.transforms as transforms
import cv2
from PIL import Image
from model import CNNPlaque
from class_names import id_to_label

# Paramètres
MODEL_PATH = "models/plaque_model.pth"
NUM_CLASSES = 43
IMAGE_SIZE = (128, 128)

# Prétraitement
transform = transforms.Compose([
    transforms.Resize(IMAGE_SIZE),
    transforms.ToTensor()
])

# Charger modèle une seule fois
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = CNNPlaque(num_classes=NUM_CLASSES).to(device)
model.load_state_dict(torch.load(MODEL_PATH, map_location=device))
model.eval()

def lire_panneau(frame):
    """Lit un panneau sur une image webcam"""
    image_pil = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    input_tensor = transform(image_pil).unsqueeze(0).to(device)

    with torch.no_grad():
        output = model(input_tensor)
        _, predicted = torch.max(output, 1)
        class_id = predicted.item()
        label = id_to_label.get(class_id, "Inconnu")

    print(f"📷 Panneau détecté : {label}")
    return class_id, label
