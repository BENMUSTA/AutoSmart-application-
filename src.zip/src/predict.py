import torch
import torchvision.transforms as transforms
from PIL import Image
import sys
from model import CNNPlaque

# ⚙️ Paramètres
MODEL_PATH = "models/plaque_model.pth"
IMAGE_PATH = "data/Test/00020.png"  # <-- modifie avec ton image test
NUM_CLASSES = 43
IMAGE_SIZE = (128, 128)

# 📦 Préparation de l’image
transform = transforms.Compose([
    transforms.Resize(IMAGE_SIZE),
    transforms.ToTensor()
])

def charger_image(image_path):
    image = Image.open(image_path).convert("RGB")
    image = transform(image).unsqueeze(0)  # Ajout dimension batch
    return image

# 🧠 Charger le modèle
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = CNNPlaque(num_classes=NUM_CLASSES).to(device)
model.load_state_dict(torch.load(MODEL_PATH, map_location=device))
model.eval()

# 📷 Charger image et prédire
image = charger_image(IMAGE_PATH).to(device)
with torch.no_grad():
    output = model(image)
    _, predicted = torch.max(output, 1)

print(f"✅ Classe prédite : {predicted.item()}")
