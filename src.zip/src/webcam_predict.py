import torch
import torchvision.transforms as transforms
import cv2
from PIL import Image
from model import CNNPlaque
from class_names import id_to_label

# ⚙️ Paramètres
MODEL_PATH = "models/plaque_model.pth"
NUM_CLASSES = 43
IMAGE_SIZE = (128, 128)

# 📦 Transformation pour les frames webcam
transform = transforms.Compose([
    transforms.Resize(IMAGE_SIZE),
    transforms.ToTensor()
])

# 🧠 Charger le modèle
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = CNNPlaque(num_classes=NUM_CLASSES).to(device)
model.load_state_dict(torch.load(MODEL_PATH, map_location=device))
model.eval()

# 🎥 Initialiser webcam
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("❌ Webcam non détectée")
    exit()

print("📡 Prédiction automatique en cours... Appuie sur [Q] pour quitter.")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # 🔁 Conversion OpenCV -> PIL -> Tensor
    image_pil = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    input_tensor = transform(image_pil).unsqueeze(0).to(device)

    # 🔍 Prédiction automatique
    with torch.no_grad():
        output = model(input_tensor)
        _, predicted = torch.max(output, 1)
        predicted_class = predicted.item()
        label = id_to_label.get(predicted_class, "Inconnu")

    # 🖼️ Affichage
    cv2.putText(frame, label, (10, 40),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

    cv2.imshow("Prédiction automatique", frame)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
