import cv2
import numpy as np

def analyser_ligne(frame):
    """
    Analyse la ligne noire dans l'image et retourne :
    - "gauche" si ligne à gauche
    - "droite" si ligne à droite
    - "tout_droit" si bien centrée
    - "inconnue" si rien détecté
    """
    # Redimensionner pour traitement rapide
    frame = cv2.resize(frame, (160, 120))
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Seuillage pour extraire ligne noire
    _, thresh = cv2.threshold(gray, 60, 255, cv2.THRESH_BINARY_INV)

    # Calcul des moments (centre de masse)
    moments = cv2.moments(thresh)
    if moments['m00'] > 0:
        cx = int(moments['m10'] / moments['m00'])  # centre en X

        if cx < 50:
            return "gauche"
        elif cx > 110:
            return "droite"
        else:
            return "tout_droit"
    else:
        return "inconnue"

# Test local (optionnel)
if __name__ == "__main__":
    cap = cv2.VideoCapture(0)

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        direction = analyser_ligne(frame)
        print("Direction :", direction)

        cv2.imshow("Cam", frame)
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()
