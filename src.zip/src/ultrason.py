import RPi.GPIO as GPIO
import time

# Configuration des broches GPIO pour HC-SR04
TRIG = 23  # GPIO 23 pour Trig
ECHO = 24  # GPIO 24 pour Echo

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)

def mesurer_distance():
    """Mesure la distance avec timeout pour éviter blocage"""
    GPIO.output(TRIG, False)
    time.sleep(0.01)

    # Envoi d'une impulsion de 10 µs
    GPIO.output(TRIG, True)
    time.sleep(0.00001)
    GPIO.output(TRIG, False)

    start_time = time.time()
    timeout = start_time + 0.05  # 50ms timeout

    # Attente début écho
    while GPIO.input(ECHO) == 0 and time.time() < timeout:
        pulse_start = time.time()
    if time.time() >= timeout:
        return -1  # erreur : pas de signal

    # Attente fin écho
    timeout = time.time() + 0.05
    while GPIO.input(ECHO) == 1 and time.time() < timeout:
        pulse_end = time.time()
    if time.time() >= timeout:
        return -1  # erreur : signal trop long

    duration = pulse_end - pulse_start
    distance = duration * 17150  # Conversion en cm
    return round(distance, 2)

# Test
if __name__ == "__main__":
    try:
        while True:
            dist = mesurer_distance()
            if dist == -1:
                print("❌ Erreur de lecture")
            else:
                print(f"Distance : {dist} cm")
            time.sleep(0.5)
    except KeyboardInterrupt:
        GPIO.cleanup()
